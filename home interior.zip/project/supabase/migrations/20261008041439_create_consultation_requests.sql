/*
# Create consultation_requests table (single-tenant, no auth)

1. New Tables
- `consultation_requests`
  - `id` (uuid, primary key)
  - `name` (text, not null) — full name of the person requesting consultation
  - `email` (text, not null) — contact email
  - `phone` (text) — optional phone number
  - `room_type` (text) — type of room to design (living room, bedroom, kitchen, etc.)
  - `budget_range` (text) — estimated budget range selected by user
  - `message` (text, not null) — details about what they want designed
  - `status` (text, default 'pending') — processing status
  - `created_at` (timestamptz, default now()) — submission timestamp
2. Security
- Enable RLS on `consultation_requests`.
- Allow anon + authenticated INSERT (anyone can request a consultation).
- Allow anon + authenticated SELECT (requests are viewable for demo purposes).
*/

CREATE TABLE IF NOT EXISTS consultation_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text NOT NULL,
  phone text,
  room_type text,
  budget_range text,
  message text NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE consultation_requests ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_consultation_requests" ON consultation_requests;
CREATE POLICY "anon_select_consultation_requests"
ON consultation_requests FOR SELECT
TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_consultation_requests" ON consultation_requests;
CREATE POLICY "anon_insert_consultation_requests"
ON consultation_requests FOR INSERT
TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_consultation_requests" ON consultation_requests;
CREATE POLICY "anon_update_consultation_requests"
ON consultation_requests FOR UPDATE
TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_consultation_requests" ON consultation_requests;
CREATE POLICY "anon_delete_consultation_requests"
ON consultation_requests FOR DELETE
TO anon, authenticated USING (true);
