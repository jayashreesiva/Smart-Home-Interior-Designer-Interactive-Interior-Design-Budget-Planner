import Navbar from '@/components/Navbar';
import Hero from '@/components/Hero';
import Rooms from '@/components/Rooms';
import Gallery from '@/components/Gallery';
import BudgetPlanner from '@/components/BudgetPlanner';
import Furniture from '@/components/Furniture';
import Designers from '@/components/Designers';
import BeforeAfter from '@/components/BeforeAfter';
import Testimonials from '@/components/Testimonials';
import Contact from '@/components/Contact';
import Footer from '@/components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-warm-50">
      <Navbar />
      <main>
        <Hero />
        <Rooms />
        <Gallery />
        <BudgetPlanner />
        <Furniture />
        <Designers />
        <BeforeAfter />
        <Testimonials />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}

export default App;
