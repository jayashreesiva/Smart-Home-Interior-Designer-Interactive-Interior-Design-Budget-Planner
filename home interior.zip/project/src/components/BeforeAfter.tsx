import { useRef, useState, useCallback } from 'react';
import { MoveHorizontal } from 'lucide-react';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';

const transformations = [
  {
    title: 'Living Room Makeover',
    before: 'https://images.pexels.com/photos/2876582/pexels-photo-2876582.jpeg?auto=compress&cs=tinysrgb&h=600&w=900',
    after: 'https://images.pexels.com/photos/8082243/pexels-photo-8082243.jpeg?auto=compress&cs=tinysrgb&h=600&w=900',
  },
];

export default function BeforeAfter() {
  const { ref, isVisible } = useScrollAnimation();
  const [sliderPos, setSliderPos] = useState(50);
  const containerRef = useRef<HTMLDivElement>(null);
  const isDragging = useRef(false);

  const handleMove = useCallback((clientX: number) => {
    const container = containerRef.current;
    if (!container) return;
    const rect = container.getBoundingClientRect();
    const x = clientX - rect.left;
    const percent = Math.max(0, Math.min(100, (x / rect.width) * 100));
    setSliderPos(percent);
  }, []);

  const handleMouseMove = useCallback(
    (e: React.MouseEvent) => {
      if (!isDragging.current) return;
      handleMove(e.clientX);
    },
    [handleMove]
  );

  const handleTouchMove = useCallback(
    (e: React.TouchEvent) => {
      if (!isDragging.current) return;
      handleMove(e.touches[0].clientX);
    },
    [handleMove]
  );

  return (
    <section className="py-24 bg-warm-50 relative overflow-hidden">
      <div
        ref={ref}
        className={`max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 transition-all duration-1000 ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
        }`}
      >
        <div className="text-center mb-16">
          <span className="inline-block px-4 py-1.5 rounded-full bg-gold-100 text-gold-700 text-sm font-semibold mb-4">
            Transformations
          </span>
          <h2 className="font-display font-bold text-3xl sm:text-4xl text-warm-900 mb-4">
            Before &{' '}
            <span className="bg-gradient-to-r from-gold-600 to-warm-600 bg-clip-text text-transparent">
              After
            </span>{' '}
            Transformations
          </h2>
          <p className="text-warm-500 max-w-2xl mx-auto leading-relaxed">
            Drag the slider to see how we transform ordinary spaces into extraordinary living
            experiences.
          </p>
        </div>

        {transformations.map((t) => (
          <div key={t.title}>
            {/* Comparison slider */}
            <div
              ref={containerRef}
              className="relative rounded-3xl overflow-hidden shadow-2xl shadow-warm-300/30 cursor-ew-resize select-none aspect-[16/10]"
              onMouseDown={() => (isDragging.current = true)}
              onMouseUp={() => (isDragging.current = false)}
              onMouseLeave={() => (isDragging.current = false)}
              onMouseMove={handleMouseMove}
              onTouchStart={() => (isDragging.current = true)}
              onTouchEnd={() => (isDragging.current = false)}
              onTouchMove={handleTouchMove}
            >
              {/* After image (background) */}
              <img
                src={t.after}
                alt="After renovation"
                className="absolute inset-0 w-full h-full object-cover"
                draggable={false}
              />
              <span className="absolute top-4 right-4 px-3 py-1.5 rounded-full bg-gold-500 text-white text-xs font-semibold z-10">
                After
              </span>

              {/* Before image (clipped) */}
              <div
                className="absolute inset-0 overflow-hidden"
                style={{ width: `${sliderPos}%` }}
              >
                <img
                  src={t.before}
                  alt="Before renovation"
                  className="absolute inset-0 h-full object-cover"
                  style={{ width: `${containerRef.current?.offsetWidth || 100}%` }}
                  draggable={false}
                />
                <span className="absolute top-4 left-4 px-3 py-1.5 rounded-full bg-warm-800 text-white text-xs font-semibold z-10">
                  Before
                </span>
              </div>

              {/* Slider handle */}
              <div
                className="absolute top-0 bottom-0 w-1 bg-white shadow-lg pointer-events-none"
                style={{ left: `${sliderPos}%` }}
              >
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-12 h-12 rounded-full bg-white shadow-xl flex items-center justify-center">
                  <MoveHorizontal className="w-5 h-5 text-warm-700" />
                </div>
              </div>
            </div>

            <p className="text-center mt-6 font-display font-semibold text-warm-900 text-lg">{t.title}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
