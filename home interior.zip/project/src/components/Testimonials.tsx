import { Quote, Star } from 'lucide-react';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';

const testimonials = [
  {
    name: 'Jennifer Adams',
    role: 'Homeowner, New York',
    image: 'https://images.pexels.com/photos/16160801/pexels-photo-16160801.jpeg?auto=compress&cs=tinysrgb&h=200&w=200',
    quote: "The team transformed our empty apartment into a warm, inviting home. Every detail was thoughtfully curated. The budget planner helped us stay on track perfectly.",
    rating: 5,
  },
  {
    name: 'Michael Stevens',
    role: 'Business Owner, LA',
    image: 'https://images.pexels.com/photos/27544052/pexels-photo-27544052.jpeg?auto=compress&cs=tinysrgb&h=200&w=200',
    quote: "Working with Olivia was incredible. She understood our vision from day one and delivered a space that exceeds everything we imagined. Truly professional.",
    rating: 5,
  },
  {
    name: 'Robert Hayes',
    role: 'Retired, Chicago',
    image: 'https://images.pexels.com/photos/35490806/pexels-photo-35490806.jpeg?auto=compress&cs=tinysrgb&h=200&w=200',
    quote: "From concept to completion, the experience was seamless. The before and after of our living room still amazes me every morning. Highly recommended!",
    rating: 5,
  },
];

export default function Testimonials() {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section className="py-24 bg-white relative overflow-hidden">
      <div className="absolute top-0 right-1/4 w-72 h-72 bg-gold-100/20 rounded-full blur-3xl" />

      <div
        ref={ref}
        className={`relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 transition-all duration-1000 ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
        }`}
      >
        <div className="text-center mb-16">
          <span className="inline-block px-4 py-1.5 rounded-full bg-warm-100 text-warm-700 text-sm font-semibold mb-4">
            Client Stories
          </span>
          <h2 className="font-display font-bold text-3xl sm:text-4xl text-warm-900 mb-4">
            What Our{' '}
            <span className="bg-gradient-to-r from-gold-600 to-warm-600 bg-clip-text text-transparent">
              Clients Say
            </span>
          </h2>
          <p className="text-warm-500 max-w-2xl mx-auto leading-relaxed">
            Real stories from homeowners who trusted us to design their dream spaces.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {testimonials.map((t, i) => (
            <div
              key={t.name}
              className="group relative bg-warm-50/50 rounded-2xl border border-warm-100 p-7 hover:shadow-xl hover:shadow-warm-300/20 hover:-translate-y-2 transition-all duration-500 overflow-hidden"
              style={{
                opacity: isVisible ? 1 : 0,
                transform: isVisible ? 'translateY(0)' : 'translateY(30px)',
                transition: `all 0.6s ease ${i * 0.15}s`,
              }}
            >
              <div className="absolute top-4 right-4 opacity-5 group-hover:opacity-10 transition-opacity">
                <Quote className="w-20 h-20 text-warm-900" fill="currentColor" />
              </div>

              <div className="relative">
                <div className="flex gap-1 mb-4">
                  {Array.from({ length: t.rating }).map((_, idx) => (
                    <Star key={idx} className="w-4 h-4 text-gold-400 fill-gold-400" />
                  ))}
                </div>

                <p className="text-warm-700 leading-relaxed mb-6 italic text-sm">
                  &ldquo;{t.quote}&rdquo;
                </p>

                <div className="flex items-center gap-3 pt-4 border-t border-warm-100">
                  <img
                    src={t.image}
                    alt={t.name}
                    className="w-12 h-12 rounded-full object-cover ring-2 ring-gold-100 group-hover:ring-gold-300 transition-all"
                  />
                  <div>
                    <p className="font-display font-semibold text-warm-900 text-sm">{t.name}</p>
                    <p className="text-xs text-warm-400">{t.role}</p>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
