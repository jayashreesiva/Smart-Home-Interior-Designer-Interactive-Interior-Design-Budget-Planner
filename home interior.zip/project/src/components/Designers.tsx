import { Calendar, Award, Star } from 'lucide-react';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';

const designers = [
  {
    name: 'Olivia Hart',
    specialization: 'Modern & Luxury Interiors',
    experience: '12 years',
    projects: 180,
    image: 'https://images.pexels.com/photos/8871903/pexels-photo-8871903.jpeg?auto=compress&cs=tinysrgb&h=500&w=400',
    rating: 4.9,
  },
  {
    name: 'David Chen',
    specialization: 'Minimalist & Contemporary',
    experience: '9 years',
    projects: 142,
    image: 'https://images.pexels.com/photos/30781749/pexels-photo-30781749.jpeg?auto=compress&cs=tinysrgb&h=500&w=400',
    rating: 4.8,
  },
  {
    name: 'Sophia Lee',
    specialization: 'Luxury & Traditional',
    experience: '15 years',
    projects: 210,
    image: 'https://images.pexels.com/photos/8560846/pexels-photo-8560846.jpeg?auto=compress&cs=tinysrgb&h=500&w=400',
    rating: 5.0,
  },
  {
    name: 'Maria Rossi',
    specialization: 'Scandinavian & Eco-Design',
    experience: '8 years',
    projects: 96,
    image: 'https://images.pexels.com/photos/30010319/pexels-photo-30010319.jpeg?auto=compress&cs=tinysrgb&h=500&w=400',
    rating: 4.7,
  },
];

export default function Designers() {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section id="designers" className="py-24 bg-gradient-to-b from-warm-100/50 to-white relative overflow-hidden">
      <div className="absolute bottom-0 left-0 w-72 h-72 bg-gold-100/30 rounded-full blur-3xl" />

      <div
        ref={ref}
        className={`relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 transition-all duration-1000 ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
        }`}
      >
        <div className="text-center mb-16">
          <span className="inline-block px-4 py-1.5 rounded-full bg-gold-100 text-gold-700 text-sm font-semibold mb-4">
            Meet Our Designers
          </span>
          <h2 className="font-display font-bold text-3xl sm:text-4xl text-warm-900 mb-4">
            Expert{' '}
            <span className="bg-gradient-to-r from-gold-600 to-warm-600 bg-clip-text text-transparent">
              Interior Designers
            </span>
          </h2>
          <p className="text-warm-500 max-w-2xl mx-auto leading-relaxed">
            Work with award-winning designers who understand your vision and bring it to life with
            passion and precision.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {designers.map((designer, i) => (
            <div
              key={designer.name}
              className="group bg-white rounded-2xl overflow-hidden border border-warm-100 hover:shadow-2xl hover:shadow-warm-300/20 hover:-translate-y-2 transition-all duration-500"
              style={{
                opacity: isVisible ? 1 : 0,
                transform: isVisible ? 'translateY(0)' : 'translateY(30px)',
                transition: `all 0.6s ease ${i * 0.12}s`,
              }}
            >
              {/* Image */}
              <div className="relative h-64 overflow-hidden">
                <img
                  src={designer.image}
                  alt={designer.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-warm-950/70 via-warm-900/10 to-transparent" />

                {/* Rating badge */}
                <div className="absolute top-4 right-4 flex items-center gap-1 px-2.5 py-1 rounded-full bg-white/80 backdrop-blur-md">
                  <Star className="w-3.5 h-3.5 text-gold-400 fill-gold-400" />
                  <span className="text-xs font-semibold text-warm-900">{designer.rating}</span>
                </div>
              </div>

              {/* Info */}
              <div className="p-5 text-center">
                <h3 className="font-display font-semibold text-lg text-warm-900 mb-1">{designer.name}</h3>
                <p className="text-sm text-gold-600 font-medium mb-3">{designer.specialization}</p>

                <div className="flex justify-center gap-4 mb-4 text-xs text-warm-400">
                  <div className="flex items-center gap-1">
                    <Award className="w-3.5 h-3.5" />
                    {designer.experience}
                  </div>
                  <div className="flex items-center gap-1">
                    <span className="font-semibold text-warm-700">{designer.projects}</span> projects
                  </div>
                </div>

                <button
                  onClick={() => document.querySelector('#contact')?.scrollIntoView({ behavior: 'smooth' })}
                  className="group/btn w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-warm-100 text-warm-700 text-sm font-semibold hover:bg-gradient-to-r hover:from-gold-500 hover:to-warm-600 hover:text-white transition-all duration-300"
                >
                  <Calendar className="w-4 h-4" />
                  Book Consultation
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
