import { useState } from 'react';
import { Heart, Eye, ArrowRight } from 'lucide-react';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';

const filters = ['All', 'Modern', 'Minimal', 'Luxury', 'Scandinavian', 'Traditional', 'Contemporary'];

const designs = [
  {
    title: 'Modern Luxury Living',
    category: 'Modern',
    image: 'https://images.pexels.com/photos/8135492/pexels-photo-8135492.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    designer: 'Olivia Hart',
    likes: 342,
  },
  {
    title: 'Minimalist Serenity',
    category: 'Minimal',
    image: 'https://images.pexels.com/photos/29012619/pexels-photo-29012619.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    designer: 'David Chen',
    likes: 278,
  },
  {
    title: 'Golden Opulence',
    category: 'Luxury',
    image: 'https://images.pexels.com/photos/33529500/pexels-photo-33529500.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    designer: 'Sophia Lee',
    likes: 512,
  },
  {
    title: 'Nordic Comfort',
    category: 'Scandinavian',
    image: 'https://images.pexels.com/photos/19966790/pexels-photo-19966790.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    designer: 'Erik Nilsson',
    likes: 189,
  },
  {
    title: 'Classic Elegance',
    category: 'Traditional',
    image: 'https://images.pexels.com/photos/1327369/pexels-photo-1327369.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    designer: 'Maria Rossi',
    likes: 234,
  },
  {
    title: 'Contemporary Chic',
    category: 'Contemporary',
    image: 'https://images.pexels.com/photos/27164969/pexels-photo-27164969.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    designer: 'James Park',
    likes: 401,
  },
  {
    title: 'Soft Minimalism',
    category: 'Minimal',
    image: 'https://images.pexels.com/photos/19980206/pexels-photo-19980206.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    designer: 'David Chen',
    likes: 167,
  },
  {
    title: 'Royal Living',
    category: 'Luxury',
    image: 'https://images.pexels.com/photos/39829283/pexels-photo-39829283.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    designer: 'Sophia Lee',
    likes: 689,
  },
  {
    title: 'Bright Nordic Kitchen',
    category: 'Scandinavian',
    image: 'https://images.pexels.com/photos/7836571/pexels-photo-7836571.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    designer: 'Erik Nilsson',
    likes: 156,
  },
];

export default function Gallery() {
  const { ref, isVisible } = useScrollAnimation();
  const [activeFilter, setActiveFilter] = useState('All');
  const [liked, setLiked] = useState<Set<number>>(new Set());

  const filteredDesigns =
    activeFilter === 'All'
      ? designs
      : designs.filter((d) => d.category === activeFilter);

  const toggleLike = (idx: number) => {
    setLiked((prev) => {
      const next = new Set(prev);
      if (next.has(idx)) next.delete(idx);
      else next.add(idx);
      return next;
    });
  };

  return (
    <section id="gallery" className="py-24 bg-white relative overflow-hidden">
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-warm-100/40 rounded-full blur-3xl" />

      <div
        ref={ref}
        className={`relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 transition-all duration-1000 ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
        }`}
      >
        <div className="text-center mb-12">
          <span className="inline-block px-4 py-1.5 rounded-full bg-warm-100 text-warm-700 text-sm font-semibold mb-4">
            Design Gallery
          </span>
          <h2 className="font-display font-bold text-3xl sm:text-4xl text-warm-900 mb-4">
            Curated{' '}
            <span className="bg-gradient-to-r from-gold-600 to-warm-600 bg-clip-text text-transparent">
              Interior Designs
            </span>
          </h2>
          <p className="text-warm-500 max-w-2xl mx-auto leading-relaxed">
            Browse our portfolio of stunning interiors. Filter by style to find inspiration that
            matches your taste.
          </p>
        </div>

        {/* Filter buttons */}
        <div className="flex flex-wrap justify-center gap-2.5 mb-12">
          {filters.map((filter) => (
            <button
              key={filter}
              onClick={() => setActiveFilter(filter)}
              className={`px-5 py-2.5 rounded-xl text-sm font-medium transition-all duration-300 ${
                activeFilter === filter
                  ? 'bg-gradient-to-r from-gold-500 to-warm-600 text-white shadow-lg shadow-gold-500/20'
                  : 'bg-warm-50 text-warm-600 hover:bg-warm-100 hover:text-warm-800'
              }`}
            >
              {filter}
            </button>
          ))}
        </div>

        {/* Gallery grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredDesigns.map((design, i) => {
            const originalIdx = designs.indexOf(design);
            return (
              <div
                key={design.title}
                className="group relative rounded-2xl overflow-hidden bg-warm-50 hover:shadow-2xl hover:shadow-warm-300/30 transition-all duration-500"
                style={{
                  opacity: isVisible ? 1 : 0,
                  transform: isVisible ? 'translateY(0)' : 'translateY(30px)',
                  transition: `all 0.5s ease ${i * 0.08}s`,
                }}
              >
                <div className="relative h-64 overflow-hidden">
                  <img
                    src={design.image}
                    alt={design.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-warm-950/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />

                  {/* Category tag */}
                  <span className="absolute top-4 left-4 px-3 py-1.5 rounded-full bg-white/80 backdrop-blur-md text-warm-800 text-xs font-semibold">
                    {design.category}
                  </span>

                  {/* Like button */}
                  <button
                    onClick={() => toggleLike(originalIdx)}
                    className="absolute top-4 right-4 w-9 h-9 rounded-full bg-white/80 backdrop-blur-md flex items-center justify-center hover:scale-110 transition-transform duration-300"
                  >
                    <Heart
                      className={`w-4 h-4 transition-colors ${
                        liked.has(originalIdx) ? 'text-red-500 fill-red-500' : 'text-warm-600'
                      }`}
                    />
                  </button>

                  {/* Hover overlay actions */}
                  <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between opacity-0 group-hover:opacity-100 group-hover:translate-y-0 translate-y-3 transition-all duration-500">
                    <div className="text-white">
                      <p className="font-display font-semibold text-sm">{design.title}</p>
                      <p className="text-xs text-white/70">by {design.designer}</p>
                    </div>
                    <button className="w-9 h-9 rounded-full bg-white/20 backdrop-blur-md flex items-center justify-center text-white hover:bg-gold-500 transition-colors">
                      <Eye className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Bottom bar */}
                <div className="p-4 flex items-center justify-between">
                  <div>
                    <h3 className="font-display font-semibold text-warm-900 text-sm">{design.title}</h3>
                    <p className="text-xs text-warm-400 mt-0.5">by {design.designer}</p>
                  </div>
                  <div className="flex items-center gap-1 text-warm-400">
                    <Heart className="w-3.5 h-3.5" />
                    <span className="text-xs">{design.likes}</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        <div className="text-center mt-12">
          <button className="group inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-warm-100 text-warm-700 font-semibold hover:bg-warm-200 hover:-translate-y-0.5 transition-all duration-300">
            View All Designs
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>
      </div>
    </section>
  );
}
