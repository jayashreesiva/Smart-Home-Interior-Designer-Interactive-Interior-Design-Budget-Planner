import { ArrowRight, Calendar, Star } from 'lucide-react';

export default function Hero() {
  const scrollToGallery = () => {
    document.querySelector('#gallery')?.scrollIntoView({ behavior: 'smooth' });
  };

  const scrollToBudget = () => {
    document.querySelector('#budget')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center pt-24 pb-12 overflow-hidden"
    >
      {/* Background image */}
      <div className="absolute inset-0">
        <img
          src="https://images.pexels.com/photos/34688219/pexels-photo-34688219.jpeg?auto=compress&cs=tinysrgb&h=1200&w=1920"
          alt="Luxury modern living room"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-warm-950/80 via-warm-950/50 to-warm-900/30" />
        <div className="absolute inset-0 bg-gradient-to-t from-warm-950/60 via-transparent to-warm-950/20" />
      </div>

      {/* Content */}
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <div className="max-w-2xl animate-fade-in-up">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 backdrop-blur-md border border-white/20 mb-6">
            <Star className="w-4 h-4 text-gold-400 fill-gold-400" />
            <span className="text-sm text-white/90 font-medium">Award-Winning Interior Design Studio</span>
          </div>

          <h1 className="font-display font-extrabold text-4xl sm:text-5xl lg:text-6xl text-white leading-[1.1] mb-6">
            Design Your{' '}
            <span className="bg-gradient-to-r from-gold-200 via-gold-400 to-gold-200 bg-clip-text text-transparent">
              Dream Home
            </span>
          </h1>

          <p className="text-lg text-white/70 mb-8 max-w-xl leading-relaxed">
            Transform your living spaces with personalized interior designs crafted by expert
            designers. Explore curated styles, plan your budget, and bring your vision to life.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 mb-12">
            <button
              onClick={scrollToGallery}
              className="group relative inline-flex items-center gap-2 px-7 py-3.5 rounded-xl bg-gradient-to-r from-gold-500 to-warm-600 text-white font-semibold shadow-lg shadow-gold-500/20 hover:shadow-xl hover:shadow-warm-700/30 hover:-translate-y-0.5 transition-all duration-300 overflow-hidden"
            >
              <span className="absolute inset-0 bg-gradient-to-r from-warm-600 to-gold-500 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              <span className="relative flex items-center gap-2">
                Explore Designs
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </span>
            </button>
            <button
              onClick={scrollToBudget}
              className="inline-flex items-center gap-2 px-7 py-3.5 rounded-xl bg-white/10 backdrop-blur-md text-white font-semibold border border-white/20 hover:bg-white/20 hover:-translate-y-0.5 transition-all duration-300"
            >
              <Calendar className="w-5 h-5" />
              Plan Your Space
            </button>
          </div>

          <div className="flex gap-8">
            {[
              { value: '500+', label: 'Projects Done' },
              { value: '250+', label: 'Happy Clients' },
              { value: '15+', label: 'Design Awards' },
            ].map((stat) => (
              <div key={stat.label}>
                <div className="font-display font-bold text-2xl text-white">{stat.value}</div>
                <div className="text-sm text-white/50 mt-1">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2">
        <span className="text-white/40 text-xs uppercase tracking-widest">Scroll</span>
        <div className="w-6 h-10 rounded-full border-2 border-white/20 flex justify-center pt-2">
          <div className="w-1.5 h-1.5 rounded-full bg-white/60 animate-scroll-down" />
        </div>
      </div>
    </section>
  );
}
