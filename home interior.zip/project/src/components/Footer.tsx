import { Home, Mail, Phone, MapPin, Facebook, Twitter, Instagram, Linkedin, ArrowUp } from 'lucide-react';

const footerLinks = [
  {
    title: 'Explore',
    links: ['Designs', 'Rooms', 'Furniture', 'Designers', 'Budget Planner'],
  },
  {
    title: 'Services',
    links: ['Interior Design', 'Consultation', '3D Visualization', 'Renovation', 'Custom Furniture'],
  },
  {
    title: 'Company',
    links: ['About Us', 'Our Team', 'Portfolio', 'Testimonials', 'Blog'],
  },
  {
    title: 'Support',
    links: ['Contact', 'FAQ', 'Privacy Policy', 'Terms', 'Shipping'],
  },
];

export default function Footer() {
  const scrollToTop = () => window.scrollTo({ top: 0, behavior: 'smooth' });

  return (
    <footer className="relative bg-warm-950 text-white overflow-hidden">
      <div className="h-1 bg-gradient-to-r from-gold-500 via-warm-600 to-gold-500" />

      <div className="absolute top-0 right-0 w-64 h-64 bg-gold-900/20 rounded-full blur-3xl" />
      <div className="absolute bottom-0 left-0 w-64 h-64 bg-warm-800/30 rounded-full blur-3xl" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid lg:grid-cols-6 gap-10">
          {/* Brand */}
          <div className="lg:col-span-2">
            <div className="flex items-center gap-2.5 mb-5">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-gold-400 to-warm-700 flex items-center justify-center shadow-lg">
                <Home className="w-5 h-5 text-white" />
              </div>
              <div className="flex flex-col leading-none">
                <span className="font-display font-bold text-lg">Smart Home</span>
                <span className="text-[10px] uppercase tracking-[0.2em] text-gold-400">
                  Interior Designer
                </span>
              </div>
            </div>
            <p className="text-sm text-white/50 leading-relaxed mb-6 max-w-sm">
              Your trusted partner in creating beautiful, functional living spaces. From concept to
              completion, we bring your interior design dreams to life.
            </p>

            <div className="space-y-2.5 text-sm">
              <div className="flex items-center gap-3 text-white/60">
                <Mail className="w-4 h-4 text-gold-400 flex-shrink-0" />
                hello@smarthome.design
              </div>
              <div className="flex items-center gap-3 text-white/60">
                <Phone className="w-4 h-4 text-gold-400 flex-shrink-0" />
                +1 (555) 123-4567
              </div>
              <div className="flex items-start gap-3 text-white/60">
                <MapPin className="w-4 h-4 text-gold-400 flex-shrink-0 mt-0.5" />
                123 Design Avenue, NYC 10001
              </div>
            </div>
          </div>

          {/* Link columns */}
          {footerLinks.map((col) => (
            <div key={col.title}>
              <h4 className="font-display font-semibold text-sm text-white mb-4 uppercase tracking-wide">
                {col.title}
              </h4>
              <ul className="space-y-2.5">
                {col.links.map((link) => (
                  <li key={link}>
                    <a
                      href="#"
                      onClick={(e) => e.preventDefault()}
                      className="text-sm text-white/50 hover:text-gold-400 transition-colors duration-200 hover:translate-x-1 inline-block"
                    >
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-12 pt-8 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-sm text-white/40">
            &copy; 2026 Smart Home Interior Designer. All rights reserved.
          </p>

          <div className="flex items-center gap-3">
            {[Facebook, Twitter, Instagram, Linkedin].map((Icon, i) => (
              <a
                key={i}
                href="#"
                onClick={(e) => e.preventDefault()}
                className="w-9 h-9 rounded-lg bg-white/5 flex items-center justify-center text-white/50 hover:bg-gradient-to-br hover:from-gold-500 hover:to-warm-600 hover:text-white hover:-translate-y-0.5 transition-all duration-300"
              >
                <Icon className="w-4 h-4" />
              </a>
            ))}

            <button
              onClick={scrollToTop}
              className="w-9 h-9 rounded-lg bg-white/5 flex items-center justify-center text-white/50 hover:bg-white/15 hover:text-white transition-all duration-300 ml-1"
              aria-label="Back to top"
            >
              <ArrowUp className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
}
