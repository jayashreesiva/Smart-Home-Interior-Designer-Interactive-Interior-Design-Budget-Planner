import { useMemo, useState } from 'react';
import { Calculator, Sofa, Ruler, Palette, Sparkles, ArrowRight } from 'lucide-react';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';

const roomTypes = [
  { name: 'Living Room', base: 1500, icon: '🛋️' },
  { name: 'Bedroom', base: 1200, icon: '🛏️' },
  { name: 'Kitchen', base: 2500, icon: '🍳' },
  { name: 'Dining Room', base: 1000, icon: '🍽️' },
  { name: 'Bathroom', base: 1800, icon: '🚿' },
  { name: 'Home Office', base: 900, icon: '💻' },
];

const roomSizes = [
  { label: 'Small (up to 100 sq ft)', multiplier: 0.8 },
  { label: 'Medium (100-200 sq ft)', multiplier: 1.0 },
  { label: 'Large (200-400 sq ft)', multiplier: 1.4 },
  { label: 'Extra Large (400+ sq ft)', multiplier: 1.8 },
];

const furnitureOptions = [
  { name: 'Sofa & Seating', cost: 800, icon: Sofa },
  { name: 'Bed & Mattress', cost: 600, icon: Sofa },
  { name: 'Dining Set', cost: 500, icon: Sofa },
  { name: 'Storage & Cabinets', cost: 400, icon: Sofa },
  { name: 'Lighting Fixtures', cost: 300, icon: Sofa },
  { name: 'Decor & Artwork', cost: 200, icon: Sofa },
];

const materialOptions = [
  { name: 'Standard', cost: 0, desc: 'Quality materials at budget-friendly prices' },
  { name: 'Premium', cost: 1500, desc: 'High-end finishes and durable materials' },
  { name: 'Luxury', cost: 3500, desc: 'Top-tier materials with custom craftsmanship' },
];

const styleOptions = [
  { name: 'Minimal', multiplier: 0.9 },
  { name: 'Modern', multiplier: 1.0 },
  { name: 'Scandinavian', multiplier: 1.1 },
  { name: 'Contemporary', multiplier: 1.15 },
  { name: 'Luxury', multiplier: 1.4 },
  { name: 'Traditional', multiplier: 1.2 },
];

export default function BudgetPlanner() {
  const { ref, isVisible } = useScrollAnimation();
  const [roomType, setRoomType] = useState(roomTypes[0]);
  const [roomSize, setRoomSize] = useState(roomSizes[1]);
  const [selectedFurniture, setSelectedFurniture] = useState<Set<number>>(new Set([0, 4]));
  const [material, setMaterial] = useState(materialOptions[1]);
  const [style, setStyle] = useState(styleOptions[1]);

  const toggleFurniture = (idx: number) => {
    setSelectedFurniture((prev) => {
      const next = new Set(prev);
      if (next.has(idx)) next.delete(idx);
      else next.add(idx);
      return next;
    });
  };

  const estimate = useMemo(() => {
    const furnitureCost = Array.from(selectedFurniture).reduce(
      (sum, idx) => sum + furnitureOptions[idx].cost,
      0
    );
    const base = roomType.base * roomSize.multiplier * style.multiplier;
    const total = base + furnitureCost + material.cost;
    return Math.round(total);
  }, [roomType, roomSize, selectedFurniture, material, style]);

  const formatCurrency = (val: number) =>
    val.toLocaleString('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 });

  return (
    <section id="budget" className="py-24 bg-gradient-to-b from-warm-50 to-warm-100/50 relative overflow-hidden">
      <div className="absolute top-0 right-0 w-96 h-96 bg-gold-100/20 rounded-full blur-3xl" />

      <div
        ref={ref}
        className={`relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 transition-all duration-1000 ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
        }`}
      >
        <div className="text-center mb-16">
          <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-gold-100 text-gold-700 text-sm font-semibold mb-4">
            <Calculator className="w-4 h-4" />
            Budget Planner
          </span>
          <h2 className="font-display font-bold text-3xl sm:text-4xl text-warm-900 mb-4">
            Plan Your{' '}
            <span className="bg-gradient-to-r from-gold-600 to-warm-600 bg-clip-text text-transparent">
              Interior Budget
            </span>
          </h2>
          <p className="text-warm-500 max-w-2xl mx-auto leading-relaxed">
            Select your preferences and get an instant estimated budget for your interior design
            project. Adjust options to see how they affect your total.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Configuration panel */}
          <div className="lg:col-span-2 space-y-6">
            {/* Room type */}
            <div className="bg-white rounded-2xl p-6 border border-warm-100 shadow-sm">
              <div className="flex items-center gap-2 mb-4">
                <Sofa className="w-5 h-5 text-gold-600" />
                <h3 className="font-display font-semibold text-warm-900">Room Type</h3>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {roomTypes.map((room) => (
                  <button
                    key={room.name}
                    onClick={() => setRoomType(room)}
                    className={`flex items-center gap-2 px-4 py-3 rounded-xl border-2 text-sm font-medium transition-all duration-300 ${
                      roomType.name === room.name
                        ? 'border-gold-500 bg-gold-50 text-gold-700'
                        : 'border-warm-100 text-warm-600 hover:border-warm-300 hover:bg-warm-50'
                    }`}
                  >
                    <span className="text-lg">{room.icon}</span>
                    {room.name}
                  </button>
                ))}
              </div>
            </div>

            {/* Room size */}
            <div className="bg-white rounded-2xl p-6 border border-warm-100 shadow-sm">
              <div className="flex items-center gap-2 mb-4">
                <Ruler className="w-5 h-5 text-gold-600" />
                <h3 className="font-display font-semibold text-warm-900">Room Size</h3>
              </div>
              <div className="grid grid-cols-2 gap-3">
                {roomSizes.map((size) => (
                  <button
                    key={size.label}
                    onClick={() => setRoomSize(size)}
                    className={`px-4 py-3 rounded-xl border-2 text-sm font-medium transition-all duration-300 text-left ${
                      roomSize.label === size.label
                        ? 'border-gold-500 bg-gold-50 text-gold-700'
                        : 'border-warm-100 text-warm-600 hover:border-warm-300 hover:bg-warm-50'
                    }`}
                  >
                    {size.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Furniture requirements */}
            <div className="bg-white rounded-2xl p-6 border border-warm-100 shadow-sm">
              <div className="flex items-center gap-2 mb-4">
                <Sparkles className="w-5 h-5 text-gold-600" />
                <h3 className="font-display font-semibold text-warm-900">Furniture Requirements</h3>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {furnitureOptions.map((item, idx) => (
                  <button
                    key={item.name}
                    onClick={() => toggleFurniture(idx)}
                    className={`flex items-center gap-2 px-4 py-3 rounded-xl border-2 text-sm font-medium transition-all duration-300 ${
                      selectedFurniture.has(idx)
                        ? 'border-gold-500 bg-gold-50 text-gold-700'
                        : 'border-warm-100 text-warm-600 hover:border-warm-300 hover:bg-warm-50'
                    }`}
                  >
                    <div
                      className={`w-4 h-4 rounded border-2 flex items-center justify-center transition-colors ${
                        selectedFurniture.has(idx) ? 'border-gold-500 bg-gold-500' : 'border-warm-300'
                      }`}
                    >
                      {selectedFurniture.has(idx) && (
                        <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                          <path d="M5 13l4 4L19 7" />
                        </svg>
                      )}
                    </div>
                    <span className="text-left">{item.name}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Materials and style — side by side */}
            <div className="grid sm:grid-cols-2 gap-6">
              <div className="bg-white rounded-2xl p-6 border border-warm-100 shadow-sm">
                <div className="flex items-center gap-2 mb-4">
                  <Palette className="w-5 h-5 text-gold-600" />
                  <h3 className="font-display font-semibold text-warm-900">Materials</h3>
                </div>
                <div className="space-y-2.5">
                  {materialOptions.map((mat) => (
                    <button
                      key={mat.name}
                      onClick={() => setMaterial(mat)}
                      className={`w-full flex items-start gap-3 px-4 py-3 rounded-xl border-2 text-left transition-all duration-300 ${
                        material.name === mat.name
                          ? 'border-gold-500 bg-gold-50'
                          : 'border-warm-100 hover:border-warm-300 hover:bg-warm-50'
                      }`}
                    >
                      <div
                        className={`mt-0.5 w-4 h-4 rounded-full border-2 flex-shrink-0 transition-colors ${
                          material.name === mat.name ? 'border-gold-500 bg-gold-500' : 'border-warm-300'
                        }`}
                      />
                      <div>
                        <p className={`text-sm font-semibold ${material.name === mat.name ? 'text-gold-700' : 'text-warm-700'}`}>
                          {mat.name}
                        </p>
                        <p className="text-xs text-warm-400 mt-0.5">{mat.desc}</p>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              <div className="bg-white rounded-2xl p-6 border border-warm-100 shadow-sm">
                <div className="flex items-center gap-2 mb-4">
                  <Sparkles className="w-5 h-5 text-gold-600" />
                  <h3 className="font-display font-semibold text-warm-900">Design Style</h3>
                </div>
                <div className="grid grid-cols-2 gap-2.5">
                  {styleOptions.map((s) => (
                    <button
                      key={s.name}
                      onClick={() => setStyle(s)}
                      className={`px-4 py-3 rounded-xl border-2 text-sm font-medium transition-all duration-300 ${
                        style.name === s.name
                          ? 'border-gold-500 bg-gold-50 text-gold-700'
                          : 'border-warm-100 text-warm-600 hover:border-warm-300 hover:bg-warm-50'
                      }`}
                    >
                      {s.name}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Results panel */}
          <div className="lg:col-span-1">
            <div className="sticky top-24 bg-gradient-to-br from-warm-900 to-warm-800 rounded-2xl p-6 text-white shadow-xl shadow-warm-900/20 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-40 h-40 bg-gold-500/10 rounded-full blur-2xl" />

              <div className="relative">
                <div className="flex items-center gap-2 mb-1">
                  <Calculator className="w-5 h-5 text-gold-400" />
                  <h3 className="font-display font-semibold text-lg">Estimated Budget</h3>
                </div>
                <p className="text-white/50 text-sm mb-6">Based on your selections</p>

                {/* Big number */}
                <div className="mb-6">
                  <div className="text-4xl font-display font-bold bg-gradient-to-r from-gold-200 to-gold-400 bg-clip-text text-transparent">
                    {formatCurrency(estimate)}
                  </div>
                  <p className="text-white/40 text-xs mt-1">Estimated total cost</p>
                </div>

                {/* Breakdown */}
                <div className="space-y-3 mb-6">
                  <div className="flex justify-between text-sm">
                    <span className="text-white/60">Room: {roomType.name}</span>
                    <span className="text-white/80">{formatCurrency(Math.round(roomType.base * roomSize.multiplier * style.multiplier))}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-white/60">Furniture ({selectedFurniture.size} items)</span>
                    <span className="text-white/80">
                      {formatCurrency(Array.from(selectedFurniture).reduce((s, i) => s + furnitureOptions[i].cost, 0))}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-white/60">Materials: {material.name}</span>
                    <span className="text-white/80">{formatCurrency(material.cost)}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-white/60">Style: {style.name}</span>
                    <span className="text-gold-400">x{style.multiplier}</span>
                  </div>
                </div>

                <div className="pt-4 border-t border-white/10">
                  <p className="text-xs text-white/40 leading-relaxed mb-4">
                    This is an estimated range. Final costs may vary based on specific requirements,
                    location, and availability.
                  </p>
                  <button
                    onClick={() => document.querySelector('#contact')?.scrollIntoView({ behavior: 'smooth' })}
                    className="group w-full inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-gradient-to-r from-gold-500 to-warm-600 text-white font-semibold hover:shadow-lg hover:shadow-gold-500/20 transition-all duration-300"
                  >
                    Get Detailed Quote
                    <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
