import { Sofa, Bed, ChefHat, UtensilsCrossed, Bath, Monitor } from 'lucide-react';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';

const rooms = [
  {
    name: 'Living Room',
    icon: Sofa,
    image: 'https://images.pexels.com/photos/8082243/pexels-photo-8082243.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    desc: 'Create a welcoming space that reflects your personality',
    styles: '12+ styles',
  },
  {
    name: 'Bedroom',
    icon: Bed,
    image: 'https://images.pexels.com/photos/6782479/pexels-photo-6782479.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    desc: 'Design a serene retreat for rest and relaxation',
    styles: '10+ styles',
  },
  {
    name: 'Kitchen',
    icon: ChefHat,
    image: 'https://images.pexels.com/photos/7587864/pexels-photo-7587864.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    desc: 'Functional and beautiful kitchens for every home',
    styles: '15+ styles',
  },
  {
    name: 'Dining Room',
    icon: UtensilsCrossed,
    image: 'https://images.pexels.com/photos/14598479/pexels-photo-14598479.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    desc: 'Gather in style with elegant dining spaces',
    styles: '8+ styles',
  },
  {
    name: 'Bathroom',
    icon: Bath,
    image: 'https://images.pexels.com/photos/6394530/pexels-photo-6394530.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    desc: 'Spa-like bathrooms for everyday luxury',
    styles: '9+ styles',
  },
  {
    name: 'Home Office',
    icon: Monitor,
    image: 'https://images.pexels.com/photos/13075330/pexels-photo-13075330.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    desc: 'Productive workspaces designed for focus',
    styles: '7+ styles',
  },
];

export default function Rooms() {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section id="rooms" className="py-24 bg-warm-50 relative overflow-hidden">
      <div className="absolute top-1/4 left-0 w-72 h-72 bg-gold-100/30 rounded-full blur-3xl" />

      <div
        ref={ref}
        className={`relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 transition-all duration-1000 ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
        }`}
      >
        <div className="text-center mb-16">
          <span className="inline-block px-4 py-1.5 rounded-full bg-gold-100 text-gold-700 text-sm font-semibold mb-4">
            Room Categories
          </span>
          <h2 className="font-display font-bold text-3xl sm:text-4xl text-warm-900 mb-4">
            Design Every{' '}
            <span className="bg-gradient-to-r from-gold-600 to-warm-600 bg-clip-text text-transparent">
              Room
            </span>{' '}
            in Your Home
          </h2>
          <p className="text-warm-500 max-w-2xl mx-auto leading-relaxed">
            From cozy bedrooms to stunning kitchens, explore tailored design solutions for every
            space in your home.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {rooms.map((room, i) => (
            <div
              key={room.name}
              className="group relative rounded-2xl overflow-hidden cursor-pointer hover:shadow-2xl hover:shadow-warm-300/30 hover:-translate-y-2 transition-all duration-500"
              style={{
                opacity: isVisible ? 1 : 0,
                transform: isVisible ? 'translateY(0)' : 'translateY(30px)',
                transition: `all 0.6s ease ${i * 0.1}s`,
              }}
            >
              <div className="relative h-72 overflow-hidden">
                <img
                  src={room.image}
                  alt={room.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-warm-950/80 via-warm-900/20 to-transparent" />

                {/* Icon badge */}
                <div className="absolute top-4 right-4 w-11 h-11 rounded-xl bg-white/20 backdrop-blur-md flex items-center justify-center group-hover:scale-110 group-hover:bg-gold-500 transition-all duration-300">
                  <room.icon className="w-5 h-5 text-white" />
                </div>

                {/* Content */}
                <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
                  <h3 className="font-display font-bold text-xl mb-1">{room.name}</h3>
                  <p className="text-sm text-white/70 mb-3">{room.desc}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-medium text-gold-300 bg-gold-500/20 backdrop-blur-sm px-3 py-1 rounded-full">
                      {room.styles}
                    </span>
                    <span className="text-sm font-medium flex items-center gap-1 opacity-0 group-hover:opacity-100 group-hover:translate-x-0 -translate-x-2 transition-all duration-300">
                      Explore
                      <ArrowRightSmall />
                    </span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function ArrowRightSmall() {
  return (
    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
      <path d="M5 12h14M12 5l7 7-7 7" />
    </svg>
  );
}
