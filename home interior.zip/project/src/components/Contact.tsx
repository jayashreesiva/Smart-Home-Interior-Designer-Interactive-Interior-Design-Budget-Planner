import { useState } from 'react';
import { Mail, Phone, MapPin, Send, CheckCircle, Loader2, Clock } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';

const roomTypes = [
  'Living Room',
  'Bedroom',
  'Kitchen',
  'Dining Room',
  'Bathroom',
  'Home Office',
  'Full Home',
];

const budgetRanges = [
  'Under $5,000',
  '$5,000 - $15,000',
  '$15,000 - $30,000',
  '$30,000 - $50,000',
  '$50,000+',
];

export default function Contact() {
  const { ref, isVisible } = useScrollAnimation();
  const [form, setForm] = useState({
    name: '',
    email: '',
    phone: '',
    room_type: '',
    budget_range: '',
    message: '',
  });
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [errorMsg, setErrorMsg] = useState('');

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus('loading');
    setErrorMsg('');

    try {
      const { error } = await supabase.from('consultation_requests').insert({
        name: form.name,
        email: form.email,
        phone: form.phone || null,
        room_type: form.room_type || null,
        budget_range: form.budget_range || null,
        message: form.message,
      });

      if (error) throw error;

      setStatus('success');
      setForm({ name: '', email: '', phone: '', room_type: '', budget_range: '', message: '' });
      setTimeout(() => setStatus('idle'), 5000);
    } catch (err) {
      setStatus('error');
      setErrorMsg(
        err instanceof Error ? err.message : 'Something went wrong. Please try again.'
      );
    }
  };

  const contactInfo = [
    { icon: Mail, label: 'Email', value: 'hello@smarthome.design', href: 'mailto:hello@smarthome.design' },
    { icon: Phone, label: 'Phone', value: '+1 (555) 123-4567', href: 'tel:+15551234567' },
    { icon: MapPin, label: 'Studio', value: '123 Design Avenue, NYC 10001', href: '#' },
  ];

  return (
    <section id="contact" className="py-24 bg-gradient-to-b from-white to-warm-50 relative overflow-hidden">
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-gold-100/30 rounded-full blur-3xl" />

      <div
        ref={ref}
        className={`relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 transition-all duration-1000 ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
        }`}
      >
        <div className="text-center mb-16">
          <span className="inline-block px-4 py-1.5 rounded-full bg-gold-100 text-gold-700 text-sm font-semibold mb-4">
            Get in Touch
          </span>
          <h2 className="font-display font-bold text-3xl sm:text-4xl text-warm-900 mb-4">
            Book a{' '}
            <span className="bg-gradient-to-r from-gold-600 to-warm-600 bg-clip-text text-transparent">
              Consultation
            </span>
          </h2>
          <p className="text-warm-500 max-w-2xl mx-auto leading-relaxed">
            Ready to transform your space? Fill out the form below and our design team will get
            back to you within 24 hours.
          </p>
        </div>

        <div className="grid lg:grid-cols-5 gap-8">
          {/* Contact info */}
          <div className="lg:col-span-2 space-y-4">
            {contactInfo.map((info) => (
              <a
                key={info.label}
                href={info.href}
                onClick={(e) => e.preventDefault()}
                className="group flex items-center gap-4 p-6 rounded-2xl bg-white border border-warm-100 hover:shadow-xl hover:shadow-warm-200/20 hover:-translate-y-1 transition-all duration-300"
              >
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-warm-100 to-gold-100 flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                  <info.icon className="w-6 h-6 text-gold-600" />
                </div>
                <div>
                  <p className="text-xs text-warm-400 uppercase tracking-wide font-semibold">
                    {info.label}
                  </p>
                  <p className="text-sm text-warm-900 font-medium mt-0.5">{info.value}</p>
                </div>
              </a>
            ))}

            <div className="p-6 rounded-2xl bg-gradient-to-br from-warm-900 to-warm-800 text-white relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-gold-500/10 rounded-full -translate-y-1/2 translate-x-1/2" />
              <div className="flex items-center gap-2 mb-3 relative">
                <Clock className="w-5 h-5 text-gold-400" />
                <h3 className="font-display font-semibold">Studio Hours</h3>
              </div>
              <div className="space-y-1 text-sm text-white/70 relative">
                <p>Mon - Fri: 9:00 AM - 7:00 PM</p>
                <p>Saturday: 10:00 AM - 4:00 PM</p>
                <p>Sunday: By appointment</p>
              </div>
            </div>
          </div>

          {/* Form */}
          <div className="lg:col-span-3">
            <div className="bg-white rounded-2xl border border-warm-100 p-8 shadow-lg shadow-warm-200/10">
              {status === 'success' ? (
                <div className="flex flex-col items-center justify-center py-16 text-center">
                  <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mb-4">
                    <CheckCircle className="w-8 h-8 text-green-600" />
                  </div>
                  <h3 className="font-display font-bold text-xl text-warm-900 mb-2">
                    Consultation Requested!
                  </h3>
                  <p className="text-warm-500 max-w-sm">
                    Thank you for reaching out. Our design team will contact you within 24 hours
                    to schedule your consultation.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div className="grid sm:grid-cols-2 gap-5">
                    <div>
                      <label className="block text-sm font-medium text-warm-900 mb-1.5">
                        Full Name <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="text"
                        name="name"
                        required
                        value={form.name}
                        onChange={handleChange}
                        placeholder="Jane Doe"
                        className="w-full px-4 py-3 rounded-xl border border-warm-200 text-sm focus:outline-none focus:ring-2 focus:ring-gold-400 focus:border-transparent transition-all bg-warm-50/50"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-warm-900 mb-1.5">
                        Email <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="email"
                        name="email"
                        required
                        value={form.email}
                        onChange={handleChange}
                        placeholder="jane@example.com"
                        className="w-full px-4 py-3 rounded-xl border border-warm-200 text-sm focus:outline-none focus:ring-2 focus:ring-gold-400 focus:border-transparent transition-all bg-warm-50/50"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-warm-900 mb-1.5">
                      Phone Number
                    </label>
                    <input
                      type="tel"
                      name="phone"
                      value={form.phone}
                      onChange={handleChange}
                      placeholder="+1 (555) 123-4567"
                      className="w-full px-4 py-3 rounded-xl border border-warm-200 text-sm focus:outline-none focus:ring-2 focus:ring-gold-400 focus:border-transparent transition-all bg-warm-50/50"
                    />
                  </div>

                  <div className="grid sm:grid-cols-2 gap-5">
                    <div>
                      <label className="block text-sm font-medium text-warm-900 mb-1.5">
                        Room Type
                      </label>
                      <select
                        name="room_type"
                        value={form.room_type}
                        onChange={handleChange}
                        className="w-full px-4 py-3 rounded-xl border border-warm-200 text-sm focus:outline-none focus:ring-2 focus:ring-gold-400 focus:border-transparent transition-all bg-warm-50/50"
                      >
                        <option value="">Select room type</option>
                        {roomTypes.map((r) => (
                          <option key={r} value={r}>{r}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-warm-900 mb-1.5">
                        Budget Range
                      </label>
                      <select
                        name="budget_range"
                        value={form.budget_range}
                        onChange={handleChange}
                        className="w-full px-4 py-3 rounded-xl border border-warm-200 text-sm focus:outline-none focus:ring-2 focus:ring-gold-400 focus:border-transparent transition-all bg-warm-50/50"
                      >
                        <option value="">Select budget range</option>
                        {budgetRanges.map((b) => (
                          <option key={b} value={b}>{b}</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-warm-900 mb-1.5">
                      Tell Us About Your Project <span className="text-red-500">*</span>
                    </label>
                    <textarea
                      name="message"
                      required
                      rows={4}
                      value={form.message}
                      onChange={handleChange}
                      placeholder="Describe your vision, style preferences, and what you'd like to achieve..."
                      className="w-full px-4 py-3 rounded-xl border border-warm-200 text-sm focus:outline-none focus:ring-2 focus:ring-gold-400 focus:border-transparent transition-all bg-warm-50/50 resize-none"
                    />
                  </div>

                  {status === 'error' && (
                    <div className="px-4 py-3 rounded-xl bg-red-50 border border-red-100 text-sm text-red-600">
                      {errorMsg}
                    </div>
                  )}

                  <button
                    type="submit"
                    disabled={status === 'loading'}
                    className="group relative w-full inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-gradient-to-r from-gold-500 to-warm-600 text-white font-semibold shadow-lg shadow-gold-500/20 hover:shadow-xl hover:shadow-warm-700/30 hover:-translate-y-0.5 transition-all duration-300 disabled:opacity-70 disabled:cursor-not-allowed disabled:hover:translate-y-0 overflow-hidden"
                  >
                    <span className="absolute inset-0 bg-gradient-to-r from-warm-600 to-gold-500 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                    <span className="relative flex items-center gap-2">
                      {status === 'loading' ? (
                        <>
                          <Loader2 className="w-5 h-5 animate-spin" />
                          Sending Request...
                        </>
                      ) : (
                        <>
                          Send Consultation Request
                          <Send className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                        </>
                      )}
                    </span>
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
