import { useEffect, useState } from 'react';
import { Home, Menu, X } from 'lucide-react';

const navLinks = [
  { label: 'Home', href: '#home' },
  { label: 'Designs', href: '#gallery' },
  { label: 'Rooms', href: '#rooms' },
  { label: 'Furniture', href: '#furniture' },
  { label: 'Designers', href: '#designers' },
  { label: 'Budget Planner', href: '#budget' },
  { label: 'Contact', href: '#contact' },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 30);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleNavClick = (href: string) => {
    setMobileOpen(false);
    document.querySelector(href)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled
          ? 'bg-warm-50/90 backdrop-blur-xl shadow-lg shadow-warm-900/5 py-3 border-b border-warm-200/50'
          : 'bg-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
        <a
          href="#home"
          onClick={(e) => {
            e.preventDefault();
            handleNavClick('#home');
          }}
          className="flex items-center gap-2.5 group"
        >
          <div className="relative">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-gold-400 to-warm-700 flex items-center justify-center shadow-lg shadow-gold-500/20 group-hover:scale-110 transition-transform duration-300">
              <Home className="w-5 h-5 text-white" />
            </div>
          </div>
          <div className="flex flex-col leading-none">
            <span
              className={`font-display font-bold text-lg tracking-tight transition-colors duration-300 ${
                scrolled ? 'text-warm-900' : 'text-white'
              }`}
            >
              Smart Home
            </span>
            <span
              className={`text-[10px] uppercase tracking-[0.2em] font-medium transition-colors duration-300 ${
                scrolled ? 'text-gold-600' : 'text-gold-300'
              }`}
            >
              Interior Designer
            </span>
          </div>
        </a>

        <div className="hidden lg:flex items-center gap-1">
          {navLinks.map((link) => (
            <a
              key={link.label}
              href={link.href}
              onClick={(e) => {
                e.preventDefault();
                handleNavClick(link.href);
              }}
              className={`relative px-4 py-2 text-sm font-medium rounded-lg transition-all duration-300 group ${
                scrolled
                  ? 'text-warm-700 hover:text-gold-600 hover:bg-warm-100'
                  : 'text-white/90 hover:text-white hover:bg-white/10'
              }`}
            >
              {link.label}
              <span className="absolute bottom-1 left-1/2 -translate-x-1/2 w-0 h-0.5 bg-gradient-to-r from-gold-400 to-warm-500 group-hover:w-3/4 transition-all duration-300" />
            </a>
          ))}
        </div>

        <button
          onClick={() => setMobileOpen(!mobileOpen)}
          className={`lg:hidden p-2 rounded-lg transition-colors ${
            scrolled ? 'text-warm-900 hover:bg-warm-100' : 'text-white hover:bg-white/10'
          }`}
          aria-label="Toggle menu"
        >
          {mobileOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      <div
        className={`lg:hidden overflow-hidden transition-all duration-500 ${
          mobileOpen ? 'max-h-96 mt-3' : 'max-h-0'
        }`}
      >
        <div className="mx-4 bg-warm-50/95 backdrop-blur-xl rounded-2xl shadow-xl p-4 space-y-1 border border-warm-200/50">
          {navLinks.map((link) => (
            <a
              key={link.label}
              href={link.href}
              onClick={(e) => {
                e.preventDefault();
                handleNavClick(link.href);
              }}
              className="block px-4 py-3 text-sm font-medium text-warm-700 hover:bg-warm-100 hover:text-gold-600 rounded-xl transition-all duration-200"
            >
              {link.label}
            </a>
          ))}
        </div>
      </div>
    </nav>
  );
}
