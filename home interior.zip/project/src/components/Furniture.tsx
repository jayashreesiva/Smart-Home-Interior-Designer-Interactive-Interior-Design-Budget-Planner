import { Star, ShoppingBag, Eye } from 'lucide-react';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';

const furniture = [
  {
    name: 'Velvet Accent Chair',
    category: 'Seating',
    price: 459,
    rating: 4.8,
    reviews: 124,
    image: 'https://images.pexels.com/photos/3328224/pexels-photo-3328224.jpeg?auto=compress&cs=tinysrgb&h=500&w=500',
    tag: 'Bestseller',
  },
  {
    name: 'Italian Leather Sofa',
    category: 'Sofa',
    price: 1280,
    rating: 4.9,
    reviews: 89,
    image: 'https://images.pexels.com/photos/11196025/pexels-photo-11196025.jpeg?auto=compress&cs=tinysrgb&h=500&w=500',
    tag: 'Premium',
  },
  {
    name: 'Lounge Accent Chair',
    category: 'Seating',
    price: 389,
    rating: 4.7,
    reviews: 67,
    image: 'https://images.pexels.com/photos/8453797/pexels-photo-8453797.jpeg?auto=compress&cs=tinysrgb&h=500&w=500',
    tag: null,
  },
  {
    name: 'Tufted Lounge Chair',
    category: 'Seating',
    price: 549,
    rating: 4.6,
    reviews: 43,
    image: 'https://images.pexels.com/photos/31844927/pexels-photo-31844927.jpeg?auto=compress&cs=tinysrgb&h=500&w=500',
    tag: 'New',
  },
  {
    name: 'Designer Lounge Chair',
    category: 'Seating',
    price: 679,
    rating: 4.9,
    reviews: 102,
    image: 'https://images.pexels.com/photos/9203451/pexels-photo-9203451.jpeg?auto=compress&cs=tinysrgb&h=500&w=500',
    tag: null,
  },
  {
    name: 'Comfort Sofa',
    category: 'Sofa',
    price: 899,
    rating: 4.5,
    reviews: 58,
    image: 'https://images.pexels.com/photos/30163102/pexels-photo-30163102.jpeg?auto=compress&cs=tinysrgb&h=500&w=500',
    tag: 'Sale',
  },
];

export default function Furniture() {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section id="furniture" className="py-24 bg-white relative overflow-hidden">
      <div className="absolute top-1/4 left-0 w-72 h-72 bg-warm-100/40 rounded-full blur-3xl" />

      <div
        ref={ref}
        className={`relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 transition-all duration-1000 ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
        }`}
      >
        <div className="text-center mb-16">
          <span className="inline-block px-4 py-1.5 rounded-full bg-warm-100 text-warm-700 text-sm font-semibold mb-4">
            Furniture Collection
          </span>
          <h2 className="font-display font-bold text-3xl sm:text-4xl text-warm-900 mb-4">
            Curated{' '}
            <span className="bg-gradient-to-r from-gold-600 to-warm-600 bg-clip-text text-transparent">
              Furniture Pieces
            </span>
          </h2>
          <p className="text-warm-500 max-w-2xl mx-auto leading-relaxed">
            Hand-picked furniture that combines comfort, style, and craftsmanship to elevate any
            living space.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {furniture.map((item, i) => (
            <div
              key={item.name}
              className="group bg-warm-50/50 rounded-2xl overflow-hidden border border-warm-100 hover:shadow-2xl hover:shadow-warm-300/20 hover:-translate-y-2 transition-all duration-500"
              style={{
                opacity: isVisible ? 1 : 0,
                transform: isVisible ? 'translateY(0)' : 'translateY(30px)',
                transition: `all 0.6s ease ${i * 0.1}s`,
              }}
            >
              {/* Image */}
              <div className="relative h-64 overflow-hidden bg-warm-100">
                <img
                  src={item.image}
                  alt={item.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                />

                {/* Tag */}
                {item.tag && (
                  <span
                    className={`absolute top-4 left-4 px-3 py-1 rounded-full text-xs font-semibold ${
                      item.tag === 'Sale'
                        ? 'bg-red-500 text-white'
                        : item.tag === 'New'
                        ? 'bg-green-500 text-white'
                        : item.tag === 'Premium'
                        ? 'bg-warm-800 text-gold-300'
                        : 'bg-gold-500 text-white'
                    }`}
                  >
                    {item.tag}
                  </span>
                )}

                {/* Quick view on hover */}
                <button className="absolute top-4 right-4 w-9 h-9 rounded-full bg-white/80 backdrop-blur-md flex items-center justify-center opacity-0 group-hover:opacity-100 group-hover:scale-100 scale-75 transition-all duration-300">
                  <Eye className="w-4 h-4 text-warm-700" />
                </button>
              </div>

              {/* Details */}
              <div className="p-5">
                <p className="text-xs text-gold-600 font-semibold uppercase tracking-wide mb-1">
                  {item.category}
                </p>
                <h3 className="font-display font-semibold text-warm-900 mb-2 group-hover:text-warm-700 transition-colors">
                  {item.name}
                </h3>

                {/* Rating */}
                <div className="flex items-center gap-2 mb-3">
                  <div className="flex items-center gap-0.5">
                    {Array.from({ length: 5 }).map((_, idx) => (
                      <Star
                        key={idx}
                        className={`w-3.5 h-3.5 ${
                          idx < Math.floor(item.rating)
                            ? 'text-gold-400 fill-gold-400'
                            : 'text-warm-200'
                        }`}
                      />
                    ))}
                  </div>
                  <span className="text-xs text-warm-400">
                    {item.rating} ({item.reviews})
                  </span>
                </div>

                {/* Price + button */}
                <div className="flex items-center justify-between pt-3 border-t border-warm-100">
                  <span className="font-display font-bold text-xl text-warm-900">
                    ${item.price}
                  </span>
                  <button className="group/btn inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-warm-900 text-white text-sm font-medium hover:bg-gold-600 transition-colors duration-300">
                    <ShoppingBag className="w-4 h-4" />
                    View Details
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
